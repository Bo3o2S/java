package Monster_Skill;

public class Boss_Skill_Act2 {

}
