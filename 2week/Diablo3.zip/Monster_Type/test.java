package Monster_Type;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Boss_Monster monster = new Boss_Monster();
		System.out.println(monster.HP);
		Unique_Monster monster2 = new Unique_Monster();
		System.out.println(monster2.HP);
	}

}
