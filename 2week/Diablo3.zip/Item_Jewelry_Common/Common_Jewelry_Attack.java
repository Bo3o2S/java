package Item_Jewelry_Common;

import Item.Jewelry;

public class Common_Jewelry_Attack extends Jewelry{
	
	public Common_Jewelry_Attack()
	{
		Item_Type = "일반";
		Item_Name = "일반 공격 보석";
		Attack = 5;
	}
}
