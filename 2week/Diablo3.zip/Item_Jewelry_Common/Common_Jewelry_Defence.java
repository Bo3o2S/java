package Item_Jewelry_Common;

import Item.Jewelry;

public class Common_Jewelry_Defence extends Jewelry{
	
	public Common_Jewelry_Defence()
	{
		Item_Type = "일반";
		Item_Name = "일반 방어 보석";
		Defence = 5;
	}
}
