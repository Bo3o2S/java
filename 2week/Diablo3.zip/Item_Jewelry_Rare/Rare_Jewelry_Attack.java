package Item_Jewelry_Rare;

import Item.Jewelry;

public class Rare_Jewelry_Attack extends Jewelry{
	
	public Rare_Jewelry_Attack()
	{
		Item_Type = "레어";
		Item_Name = "레어 공격 보석";
		Attack = 10;
	}
}
