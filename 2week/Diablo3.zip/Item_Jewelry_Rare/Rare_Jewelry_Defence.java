package Item_Jewelry_Rare;

import Item.Jewelry;

public class Rare_Jewelry_Defence extends Jewelry{
	
	public Rare_Jewelry_Defence()
	{
		Item_Type = "레어";
		Item_Name = "레어 방어 보석";
		Defence = 5;
	}
}
