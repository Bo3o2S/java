package Item;

public class Weapon extends Item{
	public double Item_Attack;
	public int Item_Vitality;
	public int Item_Strength;
	public int Item_Dex;
	public int Item_Intelligence;
	public int Item_Jewelry_Hole_Num;
	public Item_Jewelry_Hole jewelry_hole = new Item_Jewelry_Hole();
	public String Item_Type;
	public String Item_Name;
}