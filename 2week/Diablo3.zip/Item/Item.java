package Item;

public class Item {
	protected int Item_Vitality;
	protected int Item_Strength;
	protected int Item_Dex;
	protected int Item_Intelligence;
	protected String Item_Type;
	protected String Item_Name;
}
class Item_Jewelry_Hole{}