package Item;

public class Jewelry extends Item{
	public String Item_Type;
	public String Item_Name;
	public double Attack;
	public double Defence;
}
