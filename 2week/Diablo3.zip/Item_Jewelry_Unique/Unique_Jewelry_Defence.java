package Item_Jewelry_Unique;

import Item.Jewelry;

public class Unique_Jewelry_Defence extends Jewelry{
	
	public Unique_Jewelry_Defence()
	{
		Item_Type = "유니크";
		Item_Name = "유니크 방어 보석";
		Defence = 20;
	}
}
