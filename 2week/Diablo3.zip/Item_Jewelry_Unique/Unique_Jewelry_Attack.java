package Item_Jewelry_Unique;

import Item.Jewelry;

public class Unique_Jewelry_Attack extends Jewelry{
	
	public Unique_Jewelry_Attack()
	{
		Item_Type = "유니크";
		Item_Name = "유니크 공격 보석";
		Attack = 20;
	}
}
