package Job;

public interface Character_Job {
	public void Print_Status();		// 캐릭터 스탯창 출력
	public double Normal_Attack();
	public double Skill_Attack();
}
