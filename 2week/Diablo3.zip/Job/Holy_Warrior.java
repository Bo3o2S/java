package Job;

import java.util.Random;
import java.util.Scanner;

import Character.Character;

public class Holy_Warrior extends Character implements Character_Job{

	public Holy_Warrior()	// 성전사 초기화
	{
		// 성전사 기본 스탯 세팅
		Name = "성전사";
		Level_Num = 1;
		HP = 140;
		Attack = 20;
		Defence = 16;
		Evasion = 3;
		Strength = 10;  
		Dex = 8;
		Intelligence = 8;
		Recovery = 10;
		Vitality = 10;
		Defence = 16;
		Gold = 5000;
		Exp = 100;
		Full_Exp = Exp;
		
		// 레벨 증가시 수치 향상 비율
		HP_Rate = 200;
		Strength_Rate = 30; 
		Dex_Rate = 10;
		Defence_Rate = 10;
		Intelligence_Rate = 10;		
		Vitality_Rate = 10;
		Recovery_Rate = 10;
		Vital_Hp_Rate = 0.05;		
		Exp_Rate = 200;
		Attack_Rate = 20;
		Defence_Rate = 10;
		Evasion_Rate = 0.3;		
	}
	
	public int Holy_Power = 100;				// 신성력 총량

	double Damage_Justice= 2.45;				// 스킬 "정의" 공격 배수
	double Add_Damage_Justice= 2.45;			// 스킬 "정의" 추가 공격 배수
	double Damage_Fist= 5.45;					// 스킬 "천상의 주먹" 공격 배수
	double Add_Damage_Fist= 2.45;				// 스킬 "천상의 주먹" 추가 공격 배수
	
	int Holy_Power_Make_Justice = 10;			// 스킬 "정의" 신성력 생성량
	int Holy_Power_Use_Fist = 20;				// 스킬 "천상의 주먹" 신성력 사용량 			
	int Holy_Power_Make_Iron = 20;				// 스킬 "철갑피부" 신성력 생성량
	
	int Full_Holy_Power = 100;					// 신성력 최고량
	
	public double Justice()	// 스킬 "정의"
	{
		double Damage = 0;
		double Damage_Add = 0;
		Damage = Attack*Damage_Justice;				// 데미지
		Damage_Add = Attack*Add_Damage_Justice;		// 추가 데미지
		bar();
		System.out.println("정의을 시전합니다."+(int)Damage+"의 데미지를 주었습니다!");
		System.out.println("추가로 "+(int)Damage_Add+"의 데미지를 주었습니다!");
		if(Holy_Power <= (Full_Holy_Power - Holy_Power_Make_Justice))										// 신성력이 90이하인 경우
		{
			System.out.println(Holy_Power_Make_Justice + "의 신성력를 회복합니다");
			Holy_Power = Holy_Power + Holy_Power_Make_Justice;
		}
		else if(Holy_Power > (Full_Holy_Power - Holy_Power_Make_Justice) && Holy_Power < Full_Holy_Power)	// 신성력이 91 ~ 99 일 때
		{
			System.out.println((Full_Holy_Power-Holy_Power) + "의 신성력를 회복합니다");			
			Holy_Power = 100;
		}
		else //신성력 100% 일 때
		{
			System.out.println("신성력이 꽉찼습니다");
		}
		System.out.println("현재 신성력량 "+Holy_Power);	// 현재 신성력 량 
		bar();
		Damage = Damage + Damage_Add;
		return Damage;
	}
	
	public double Fist_of_Heaven()	// 스킬 "천상의 주먹" 
	{
		double Damage = 0;
		double Damage_Add = 0;
		Damage = Attack*Damage_Fist;			// 기본 데미지
		Damage_Add = Attack*Add_Damage_Fist;	// 추가 데미지
		if(Holy_Power >= Holy_Power_Use_Fist)	// 신성력 량이 충분할 때(신성력 20 이상)
		{
			Holy_Power = Holy_Power - Holy_Power_Use_Fist; // 남은 신성력
			bar();
			System.out.println("천상의 주먹을 시전합니다."+(int)Damage+"의 데미지를 주었습니다!");
			System.out.println("추가로 "+(int)Damage_Add+" 데미지를 주었습니다!");
			System.out.println("신성력이 "+Holy_Power_Use_Fist+"만큼 감소합니다.");
			System.out.println("현재 신성력량 "+Holy_Power);
			bar();
			return Damage;
		}
		else	// 신성력이 부족할 때
		{
			System.out.println("신성력이 부족합니다. 현재 신성력량 " + Holy_Power);
			Damage = 0;
			return Damage;
		}
	}
	
	public double Iron_Skin()	// 스킬 "철갑 피부" 
	{
		Defence = Defence + Defence*0.2;
		HP = HP + HP*0.1;
		System.out.println("방어력이 " + Defence*0.2 +"만큼 증가하였습니다\n");
		System.out.println("HP가 " + HP*0.1 +"만큼 증가하였습니다\n");
		
		if(Holy_Power <= (Full_Holy_Power - Holy_Power_Make_Iron))										// 신성력이 80이하인 경우
		{
			System.out.println(Holy_Power_Make_Iron + "의 신성력를 회복합니다");
			Holy_Power = Holy_Power + Holy_Power_Make_Iron;
		}
		else if(Holy_Power > (Full_Holy_Power - Holy_Power_Make_Iron) && Holy_Power < Full_Holy_Power)	// 신성력이 81 ~ 89 일 때
		{
			System.out.println((Full_Holy_Power-Holy_Power) + "의 신성력를 회복합니다");			
			Holy_Power = 100;
		}
		else //신성력 100% 일 때
		{
			System.out.println("신성력이 꽉찼습니다");
		}
		System.out.println("현재 신성력량 "+Holy_Power);	// 현재 신성력 량
		bar();
		
		System.out.println("신성력이 " + Holy_Power_Make_Iron +"만큼 증가하였습니다\n");
		bar();
		return 0;
	}
	
	public void Print_Status() {	// 캐릭터 상태창 출력
		// TODO Auto-generated method stub
		bar();
		System.out.println("아이디: " + ID);
		System.out.println("직업명 : " + Name);
		System.out.println("레벨 : " + Level_Num);
		System.out.println("신성력 : " + Holy_Power);
		System.out.println("전체 생명력 : " + HP);
		System.out.println("현재 생명력 : " + HP);
		System.out.println("힘 : " + Strength);
		System.out.println("민첩 : " + Dex);
		System.out.println("지능 : " + Intelligence);
		System.out.println("활력 : " + Vitality);
		System.out.println("공격력 : " + Attack);
		System.out.println("방어력 : " + Defence);
		System.out.println("회복력 : " + Recovery);
		System.out.println("회피력 : " + Evasion);
		System.out.println("골드 : " + Gold);
		System.out.println("경험치: " + (Full_Exp-Exp) + "/" + Full_Exp);
		bar2();
	}
	
	@Override
	public double Normal_Attack() {	// 일반 공격
		// TODO Auto-generated method stub
		double Damage = 0;
		Damage = Attack;
		System.out.println(Name + "가 " + Attack + "만큼의 데미지를 입힙니다");		// 몬스터에게 주는 데미지
		return Damage;
	}
	
	@Override
	public double Skill_Attack() {
		// TODO Auto-generated method stub
		double Damage = 0;		// 몬스터에 주는 데미지
		Random random = new Random();	
		int Skill_Num = Skill_Choice();	// 스킬 선택
		
		if(Skill_Num == 1)	// 스킬 "정의" 사용시
		{
			Damage = Justice();
		}			
		else if(Skill_Num == 2)	// 스킬 "천상의 주먹" 사용시
		{
			Damage = Fist_of_Heaven();
		}
		else if(Skill_Num == 3) // 스킬 "철갑 피부" 사용시
		{
			Iron_Skin();
		}
		return Damage;
	}	
	
	public int Skill_Choice()	// 스킬 선택
	{
		Scanner scan = new Scanner(System.in);
		bar2();
		System.out.println("1. 굶주린 화살");
		System.out.println("2. 투검");
		System.out.println("3. 공격력 증가");
		bar2();
		System.out.println("선택하기(1~3) : ");
		int num = scan.nextInt();
		scan.nextLine();
		
		return num;
	}
}
